from django.urls import path
from .views import (
    get_student_courses,
    get_student_assignments,
    get_student_exams,
    get_student_grades,
    get_student_schedule,
    admin_create_user,
    admin_edit_user,
    admin_delete_user,
    admin_list_users,
    parent_view_grades,
    parent_view_attendance,
    parent_view_payment_history,
    parent_receive_notifications,
    teacher_publish_resources,
    teacher_enter_grades,
    teacher_edit_grades,
    teacher_create_assessments,
    teacher_mark_attendance,
    teacher_send_notifications,
    student_view_grades,
    student_view_schedule,
    student_download_resources,
    student_submit_assignments,
    student_view_attendance,
    student_communicate_with_teachers,
    finance_manage_tuition_fee,
    finance_track_expenses,
    notification_send,
)

urlpatterns = [
    path('student/<int:student_id>/courses/', get_student_courses),
    path('student/<int:student_id>/assignments/', get_student_assignments),
    path('student/<int:student_id>/exams/', get_student_exams),
    path('student/<int:student_id>/grades/', get_student_grades),
    path('student/<int:student_id>/schedule/', get_student_schedule),

    # Admin endpoints
    path('admin/create_user/', admin_create_user),
    path('admin/edit_user/<int:user_id>/', admin_edit_user),
    path('admin/delete_user/<int:user_id>/', admin_delete_user),
    path('admin/list_users/', admin_list_users),

    # Parent endpoints
    path('parent/<int:parent_id>/grades/', parent_view_grades),
    path('parent/<int:parent_id>/attendance/', parent_view_attendance),
    path('parent/<int:parent_id>/payment_history/', parent_view_payment_history),
    path('parent/<int:parent_id>/notifications/', parent_receive_notifications),

    # Teacher endpoints
    path('teacher/<int:teacher_id>/publish_resources/', teacher_publish_resources),
    path('teacher/<int:teacher_id>/enter_grades/', teacher_enter_grades),
    path('teacher/<int:teacher_id>/edit_grades/', teacher_edit_grades),
    path('teacher/<int:teacher_id>/create_assessments/', teacher_create_assessments),
    path('teacher/<int:teacher_id>/mark_attendance/', teacher_mark_attendance),
    path('teacher/<int:teacher_id>/send_notifications/', teacher_send_notifications),

    # Student endpoints
    path('student/<int:student_id>/view_grades/', student_view_grades),
    path('student/<int:student_id>/view_schedule/', student_view_schedule),
    path('student/<int:student_id>/download_resources/', student_download_resources),
    path('student/<int:student_id>/submit_assignments/', student_submit_assignments),
    path('student/<int:student_id>/view_attendance/', student_view_attendance),
    path('student/<int:student_id>/communicate_with_teachers/', student_communicate_with_teachers),

    # FinanceOffice endpoints
    path('finance/<int:finance_id>/manage_tuition_fee/', finance_manage_tuition_fee),
    path('finance/<int:finance_id>/track_expenses/', finance_track_expenses),

    # Notification endpoint
    path('notification/<int:notification_id>/send/', notification_send),
]
