# --- Endpoints administrateur ---
from django.views.decorators.csrf import csrf_exempt
from .models import Administrator, User, Parent, Teacher, Student, FinanceOffice, Notification, Attendance, Grade, Assignment, Subject, ClassRoom
from django.http import JsonResponse
import json

@csrf_exempt
def admin_create_user(request):
	if request.method == 'POST':
		data = json.loads(request.body)
		if User.objects.filter(username=data['username']).exists():
			return JsonResponse({'error': 'Username already exists'}, status=400)
		user = User.objects.create_user(
			username=data['username'],
			email=data.get('email', ''),
			password=data.get('password', '1234'),
			role=data.get('role', 'student')
		)
		# Crée le profil selon le rôle
		profile_id = None
		if user.role == 'student':
			profile = Student.objects.create(user=user)
			profile_id = profile.user_id
		elif user.role == 'teacher':
			profile = Teacher.objects.create(user=user)
			profile_id = profile.user_id
		elif user.role == 'parent':
			profile = Parent.objects.create(user=user)
			profile_id = profile.user_id
		elif user.role == 'admin':
			profile = Administrator.objects.create(user=user)
			profile_id = profile.user_id
		elif user.role == 'finance':
			profile = FinanceOffice.objects.create(user=user)
			profile_id = profile.user_id
		return JsonResponse({'id': profile_id, 'username': user.username, 'role': user.role})
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def admin_edit_user(request, user_id):
	if request.method == 'PUT':
		data = json.loads(request.body)
		try:
			user = User.objects.get(pk=user_id)
			user.email = data.get('email', user.email)
			old_role = user.role
			new_role = data.get('role', user.role)
			user.role = new_role
			user.save()
			# Met à jour le profil si le rôle change
			if old_role != new_role:
				# Supprime l'ancien profil
				if old_role == 'student': Student.objects.filter(user=user).delete()
				elif old_role == 'teacher': Teacher.objects.filter(user=user).delete()
				elif old_role == 'parent': Parent.objects.filter(user=user).delete()
				elif old_role == 'admin': Administrator.objects.filter(user=user).delete()
				elif old_role == 'finance': FinanceOffice.objects.filter(user=user).delete()
				# Crée le nouveau profil
				if new_role == 'student': Student.objects.create(user=user)
				elif new_role == 'teacher': Teacher.objects.create(user=user)
				elif new_role == 'parent': Parent.objects.create(user=user)
				elif new_role == 'admin': Administrator.objects.create(user=user)
				elif new_role == 'finance': FinanceOffice.objects.create(user=user)
			return JsonResponse({'id': user.id, 'username': user.username, 'role': user.role})
		except User.DoesNotExist:
			return JsonResponse({'error': 'User not found'}, status=404)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def admin_delete_user(request, user_id):
	if request.method == 'DELETE':
		try:
			user = User.objects.get(pk=user_id)
			user.delete()
			return JsonResponse({'success': True})
		except User.DoesNotExist:
			return JsonResponse({'error': 'User not found'}, status=404)
	return JsonResponse({'error': 'Invalid method'}, status=405)

def admin_list_users(request):
	users = User.objects.all()
	data = [{'id': u.id, 'username': u.username, 'role': u.role, 'email': u.email} for u in users]
	return JsonResponse(data, safe=False)

# --- Endpoints parent ---
@csrf_exempt
def parent_view_grades(request, parent_id):
	if request.method == 'GET':
		parent = Parent.objects.get(pk=parent_id)
		grades = Grade.objects.filter(student__in=parent.students.all())
		data = [{'student': g.student.user.username, 'subject': g.subject.subjectName, 'score': g.score} for g in grades]
		return JsonResponse(data, safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def parent_view_attendance(request, parent_id):
	if request.method == 'GET':
		parent = Parent.objects.get(pk=parent_id)
		attendance = Attendance.objects.filter(student__in=parent.students.all())
		data = [{'student': a.student.user.username, 'date': a.date, 'status': a.status} for a in attendance]
		return JsonResponse(data, safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def parent_view_payment_history(request, parent_id):
	if request.method == 'GET':
		# Placeholder: à adapter selon la logique métier
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def parent_receive_notifications(request, parent_id):
	if request.method == 'GET':
		parent = Parent.objects.get(pk=parent_id)
		notifications = Notification.objects.filter(user=parent.user)
		data = [{'message': n.message, 'date': n.date} for n in notifications]
		return JsonResponse(data, safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

# --- Endpoints teacher ---
@csrf_exempt
def teacher_publish_resources(request, teacher_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def teacher_enter_grades(request, teacher_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def teacher_edit_grades(request, teacher_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def teacher_create_assessments(request, teacher_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def teacher_mark_attendance(request, teacher_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def teacher_send_notifications(request, teacher_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

# --- Endpoints student ---
@csrf_exempt
def student_view_grades(request, student_id):
	if request.method == 'GET':
		grades = Grade.objects.filter(student_id=student_id)
		data = [{'subject': g.subject.subjectName, 'score': g.score, 'comment': g.comment} for g in grades]
		return JsonResponse(data, safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def student_view_schedule(request, student_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def student_download_resources(request, student_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def student_submit_assignments(request, student_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def student_view_attendance(request, student_id):
	if request.method == 'GET':
		attendance = Attendance.objects.filter(student_id=student_id)
		data = [{'date': a.date, 'status': a.status} for a in attendance]
		return JsonResponse(data, safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def student_communicate_with_teachers(request, student_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

# --- Endpoints financeoffice ---
@csrf_exempt
def finance_manage_tuition_fee(request, finance_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
def finance_track_expenses(request, finance_id):
	if request.method == 'GET':
		# Placeholder: à adapter
		return JsonResponse([], safe=False)
	return JsonResponse({'error': 'Invalid method'}, status=405)

# --- Endpoints notification ---
@csrf_exempt
def notification_send(request, notification_id):
	if request.method == 'POST':
		# Placeholder: à adapter
		return JsonResponse({'success': True})
	return JsonResponse({'error': 'Invalid method'}, status=405)
# --- Endpoints étudiants ---
from django.http import JsonResponse
from .models import Student, Grade, Assignment, Subject, Attendance, ClassRoom
from django.views.decorators.csrf import csrf_exempt

def get_student_courses(request, student_id):
	try:
		student = Student.objects.get(pk=student_id)
		courses = []
		if student.classroom:
			subjects = Subject.objects.all()  # à adapter selon la logique métier
			for subj in subjects:
				courses.append({
					'id': subj.id,
					'name': subj.subjectName,
				})
		return JsonResponse(courses, safe=False)
	except Student.DoesNotExist:
		return JsonResponse({'error': 'Student not found'}, status=404)

def get_student_assignments(request, student_id):
	try:
		student = Student.objects.get(pk=student_id)
		assignments = Assignment.objects.filter(subject__in=Subject.objects.all())  # à adapter
		data = [
			{
				'id': a.id,
				'title': a.title,
				'subject': a.subject.subjectName,
			} for a in assignments
		]
		return JsonResponse(data, safe=False)
	except Student.DoesNotExist:
		return JsonResponse({'error': 'Student not found'}, status=404)

def get_student_exams(request, student_id):
	# Placeholder: à adapter selon la logique métier
	return JsonResponse([], safe=False)

def get_student_grades(request, student_id):
	try:
		student = Student.objects.get(pk=student_id)
		grades = Grade.objects.filter(student=student)
		data = [
			{
				'subject': g.subject.subjectName,
				'score': g.score,
				'comment': g.comment,
			} for g in grades
		]
		return JsonResponse(data, safe=False)
	except Student.DoesNotExist:
		return JsonResponse({'error': 'Student not found'}, status=404)

def get_student_schedule(request, student_id):
	# Placeholder: à adapter selon la logique métier
	return JsonResponse([], safe=False)
from django.shortcuts import render

# Create your views here.
