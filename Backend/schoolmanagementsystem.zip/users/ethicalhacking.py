from flask import Flask, request, jsonify

app = Flask(__name__)

# Stockage simple en mémoire
tickets_available = 50
reservations = []

@app.route('/buy_ticket', methods=['POST'])
def buy_ticket():
    global tickets_available
    data = request.json

    # Pas de vérification du nombre maximum par utilisateur
    # Pas de captcha, pas de throttling
    quantity = data.get("quantity", 1)
    user = data.get("user", "anonymous")

    if tickets_available >= quantity:
        tickets_available -= quantity
        reservations.append({"user": user, "quantity": quantity})
        return jsonify({
            "message": f"Reservation successful for {quantity} tickets.",
            "tickets_left": tickets_available
        }), 200
    else:
        return jsonify({"error": "Not enough tickets left."}), 400


@app.route('/reservations', methods=['GET'])
def get_reservations():
    return jsonify(reservations), 200


if __name__ == '__main__':
    app.run(debug=True, port=5000)
